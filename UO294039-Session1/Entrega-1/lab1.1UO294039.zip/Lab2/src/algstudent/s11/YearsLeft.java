package algstudent.s11;

import java.util.Date;

public class YearsLeft {

	public static void main(String[] args) {
		long max = Long.MAX_VALUE;
		Date date = new Date(max);
		long current = System.currentTimeMillis();
		Date today = new Date(current);
		int years_left = date.getYear() - today.getYear();
		System.out.println(years_left);

	}

}
