package algstudent.s11;

public class Vector7 {

	static int[] v;

	public static void main(String arg []) {
		int repetitions = Integer.parseInt(arg[0]);
		long t1,t2;
		int matches2 = 0;
		
		for (int n=10000; n<=81920000; n*=2){ //n is increased *5   
			  v = new int[n];
			  Vector1.fillIn(v);
			  
			  t1 = System.currentTimeMillis();
			  //We have to repeat the whole process to be measured
			  for (int repetition=1; repetition<=repetitions; repetition++){    	
				  int[] m = new int[n];
				  matches2 = Vector1.matches2(v, m);
			  }
			  t2 = System.currentTimeMillis();
			  System.out.printf("SIZE=%d TIME=%d milliseconds MATCHES!=%d NTIMES=%d\n", n, t2-t1, matches2, repetitions);	
		}//for 
	}

}
