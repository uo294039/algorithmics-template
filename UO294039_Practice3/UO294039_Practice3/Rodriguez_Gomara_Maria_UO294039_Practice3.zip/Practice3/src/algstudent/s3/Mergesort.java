package algstudent.s3;

import java.util.Random;

public class Mergesort {

	static int[] v;

	public static void mergesort(int[] v) {
		mergesort(v, 0, v.length - 1);
	}

	private static void mergesort(int[] v, int left, int right){
		if (right>left) {
			int center = (left+right)/2;
			mergesort(v, left, center);
			mergesort(v, center+1, right);
			combine(v, left, center, center+1, right);
		}
	}

	private static void combine(int[] elements, int x1, int x2, int y1, int y2) {
		int sizeX = x2-x1+1;
		int sizeY = y2-y1+1;
		
		int[] x = new int[sizeX];
		int[] y = new int[sizeY];
		
		for (int i = 0; i < sizeX; i++){
			x[i] = elements[x1+i];
		}
		
		for (int i = 0; i < sizeY; i++){
			y[i] = elements[y1+i];
		}
		
		int counterX = 0;
		int counterY = 0;
		int elementsX = 0;
		int elementsY = 0;
		
		while (counterX<sizeX || counterY<sizeY) {
			if (counterX>=sizeX) {
				elementsX=(int) Double.POSITIVE_INFINITY;
			} else {
				elementsX=x[counterX];
			}
			
			if (counterY>=sizeY) {
				elementsY=(int) Double.POSITIVE_INFINITY;
			} else {
				elementsY=y[counterY];
			}
			
			if(elementsX>elementsY) {
				elements[x1+counterX+counterY]=elementsY;
				counterY++;
			} else {
				elements[x1+counterX+counterY]=elementsX;
				counterX++;
			}
				
		}
	}
	
	/* This method returns already sorted values */
	public static void sorted(int[] a) {
		int n = a.length;
		for (int i = 0; i < n; i++)
			a[i] = i;
	}

	/* This method gives values sorted in reverse order */
	public static void reverseSorted(int[] a) {
		int n = a.length;
		for (int i = 0; i < n; i++)
			a[i] = n - i - 1;
	}

	/* This method gives random values to a vector of integers, it uses the Random class from the java.util package */
	public static void randomSorted(int[] a) {
		Random r = new Random();
		int n = a.length;
		for (int i = 0; i < n; i++)
			a[i] = r.nextInt(100000);
	}


}
