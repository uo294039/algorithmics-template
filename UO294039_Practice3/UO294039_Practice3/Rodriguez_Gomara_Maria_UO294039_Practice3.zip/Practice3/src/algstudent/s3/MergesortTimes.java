package algstudent.s3;



public class MergesortTimes {
	
	static int[] v;
	
	public static void main(String arg[]) {
		long t1, t2;
		String opcion = arg[0];

		for (int n = 31250; n <= Integer.MAX_VALUE; n *= 2) {
			v = new int[n];

			if (opcion.compareTo("ordered") == 0)
				Mergesort.sorted(v);
			else if (opcion.compareTo("reverse") == 0)
				Mergesort.reverseSorted(v);
			else
				Mergesort.randomSorted(v);

			t1 = System.currentTimeMillis();

			Mergesort.mergesort(v);

			t2 = System.currentTimeMillis();

			System.out.println(n + "\t" + (t2 - t1));
		}
	}

}
