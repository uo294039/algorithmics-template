package algstudent.s11;

import java.util.Date;

public class YearsLeft {

	public static void main(String[] args) {
		long max = Long.MAX_VALUE;
		Date date = new Date(max);
		System.out.println(date);

	}

}
